//
//  StudentByID.swift
//  Project4
//
//  Created by Mohammed Mujadib on 28/10/1441 AH.
//  Copyright © 1441 mohammed al mujadib. All rights reserved.
//

import Foundation
struct StudentByID: Codable {
    let firstname: String
    let lastname: String
    let key: String
    
    enum codingkey: String,CodingKey{
        case firstname = "first_name"
        case lastname = "last_name"
        case key
    }
}
