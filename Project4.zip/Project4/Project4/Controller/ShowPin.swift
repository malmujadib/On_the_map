//
//  ShowPin.swift
//  Project4
//
//  Created by Mohammed Mujadib on 22/11/1441 AH.
//  Copyright © 1441 mohammed al mujadib. All rights reserved.
//

import UIKit
import MapKit

class ShowPin: UIViewController,MKMapViewDelegate {
    
    

    @IBOutlet weak var mapView: MKMapView!
    
    var placeMark:CLPlacemark?
    var mediaURL:String?
    override func viewDidLoad() {
        super.viewDidLoad()
        mapView.delegate=self
        print(placeMark!)
        print(mediaURL!)
        addAnnotation()
    }
    func addAnnotation(){
        if let placeMark=placeMark{
            let annotation=MKPointAnnotation()
            annotation.coordinate=placeMark.location!.coordinate
            annotation.title=placeMark.name!
            mapView.addAnnotation(annotation)
            let region=MKCoordinateRegion(center: placeMark.location!.coordinate, span: MKCoordinateSpan(latitudeDelta: 0.25, longitudeDelta: 0.25))
            mapView.setRegion(region, animated: true)
        }
    }
    @IBAction func addPin(_ sender: UIButton) {
        network.StudentID(completionHandler: {(response,error) in
            if let response=response{
                self.postOrPutLocation(studentById:response)
            }else{
                self.errorAlert(error,stringError:"Unable to get user information")
            }
        })
    }
    
    
    func postOrPutLocation(studentById:StudentByID){
    
        if let locationId = LocationData.LocationID{
            network.putloca(studentById, mediaURL!, locationName: placeMark!.name!, longitude: placeMark!.location!.coordinate.longitude, latitude: placeMark!.location!.coordinate.latitude, objectId: locationId, completionHandler: {(response,error) in
                
                if let _ = response{
                    self.successAlert(stringSuccess: "Student location Updated.")
                    
                }else{
                    self.errorAlert(error, stringError: "Unable to post location")
                }
            })
        }else{
            network.Postloca(studentById, mediaURL!, locationName: placeMark!.name!, longitude: placeMark!.location!.coordinate.longitude, latitude: placeMark!.location!.coordinate.latitude, completionHandler: {(response,error) in
                
                if let response=response{
                    LocationData.LocationID=response.objectId
                    self.successAlert(stringSuccess: "Student location Posted.")
                }else{
                    
                    self.errorAlert(error, stringError: "Unable to post location")
                }
            })
        }
    }
    @IBAction func cancelPinAddition(_ sender: UIBarButtonItem) {
        dismiss(animated: true, completion: nil)
    }
}

