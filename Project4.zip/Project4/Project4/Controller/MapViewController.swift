//
//  MapViewController.swift
//  Project4
//
//  Created by Mohammed Mujadib on 22/11/1441 AH.
//  Copyright © 1441 mohammed al mujadib. All rights reserved.
//
import UIKit
import MapKit
class MapViewController: UIViewController, MKMapViewDelegate{
    @IBOutlet weak var mapView: MKMapView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        mapView.delegate=self
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        network.Student(completionHandler: {(result,error) in
            if !result.isEmpty{
                StudentData.list=result
                self.addAnnotions(StudentData.list)
            }else{
                self.errorAlert(error,stringError:"Unable to fetch other students")
            }
        })
    }
    
    @IBAction func goPinAddition(_ sender: UIBarButtonItem) {
        
        performSegue(withIdentifier: "addPin", sender: nil)
    }
    @IBAction func logout(_ sender: UIBarButtonItem) {
        
        network.Logout(completionHandler: {(success,error) in
            if success{
                LocationData.LocationID=nil
                self.dismiss(animated: true, completion: {() in
                    print("Session id: \(network.authorization.session)")
                    print("Uinique id: \(network.authorization.account)")
                    print("loggin out")
                    
                })
            }else{
                self.errorAlert(error,stringError:"Unable to logout")
            }
        })
    }
}
extension MapViewController{
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        var customAnnotationView=mapView.dequeueReusableAnnotationView(withIdentifier: "studentAnnotation") as? MKMarkerAnnotationView
        if customAnnotationView==nil{
            customAnnotationView=MKMarkerAnnotationView(annotation: annotation, reuseIdentifier: "studentAnnotation")
            customAnnotationView?.canShowCallout=true
            customAnnotationView?.markerTintColor=UIColor.orange
            customAnnotationView?.rightCalloutAccessoryView=UIButton(type: .detailDisclosure)
            
        }
        else{
            customAnnotationView?.annotation=annotation
        }
        
        return customAnnotationView
    }
    
    func addAnnotions(_  students:[student]){
        var annotations=[MKAnnotation]()
        for student in students{
            let annotation=MKPointAnnotation()
            
            annotation.coordinate=CLLocationCoordinate2D(latitude: CLLocationDegrees(student.latitude), longitude: CLLocationDegrees(student.longitude))
            annotation.title=student.firstName+" "+student.lastName
            annotation.subtitle=student.mediaURL
            
            annotations.append(annotation)
        }
        mapView.addAnnotations(annotations)
    }
    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl) {
        if let url=URL(string: (view.annotation?.subtitle!)!){
            UIApplication.shared.open(url, completionHandler: {(success) in
                if success{
                    print("The URL was delivered successfully")
                }else{
                    DispatchQueue.main.async{
                        self.errorAlert(network.error.URLerror,stringError:"the url was not delivered successfully")
                    }
                }
            })
        }else{
            DispatchQueue.main.async{
                self.errorAlert(network.error.URLerror,stringError: "Unable to unwrap optional url")
            }
        }
        
    }
}
