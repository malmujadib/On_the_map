//
//  listViewController.swift
//  Project4
//
//  Created by Mohammed Mujadib on 28/10/1441 AH.
//  Copyright © 1441 mohammed al mujadib. All rights reserved.
//
import UIKit


class listViewCintroller: UIViewController{
    
    
    @IBOutlet weak var table: UITableView!
    
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        network.Student(completionHandler: {(result,error) in
            
            //if the result is not empty
            if !result.isEmpty{
                StudentData.list=result
                //reload the tableView
                self.table.reloadData()
            }else{
                self.showAlert(error,customError:"Unable to fetch other students")
            }
        })
    }
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        table.delegate = self
        table.dataSource = self
    }
    
    
    
    func showAlert(_ error:Error?,customError:String){
        var alert:UIAlertController
        if let error=error{
            alert=UIAlertController(title: "Error", message:error.localizedDescription, preferredStyle: .alert)
        }
        else{
            alert=UIAlertController(title: "Error", message:customError, preferredStyle: .alert)
        }
        
        let action=UIAlertAction(title: "ok", style: .default, handler: nil)
        alert.addAction(action)
        
        self.present(alert, animated: true, completion: nil)
        
    }
    @IBAction func logout(_ sender: UIBarButtonItem) {
        
        network.Logout(completionHandler: {(success,error) in
            if success{
                
                LocationData.LocationID=nil
                self.dismiss(animated: true, completion: {() in
                    print("Session id: \(network.authorization.session)")
                    print("Uinique id: \(network.authorization.account)")
                    print("loggin out")
                    
                })
            }else{
                self.showAlert(error,customError:"Unable to logout")
            }
        })
    }
    @IBAction func goToPinAddition(_ sender: UIBarButtonItem) {
        
        performSegue(withIdentifier: "addPin", sender: nil)
    }
}
extension listViewCintroller:UITableViewDataSource,UITableViewDelegate{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return StudentData.list.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell=tableView.dequeueReusableCell(withIdentifier: "studentCell", for: indexPath)
        cell.textLabel?.text=StudentData.list[indexPath.row].firstName+" "+StudentData.list[indexPath.row].lastName
        cell.detailTextLabel?.text=StudentData.list[indexPath.row].mediaURL
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        if let url=URL(string: StudentData.list[indexPath.row].mediaURL){
            UIApplication.shared.open(url, completionHandler: {(success) in
                if success{
                    print("The URL was delivered successfully")
                }else{
                    DispatchQueue.main.async{
                        self.showAlert(network.error.URLerror,customError: "The URL was no delivery successully")
                    }
                }
            })
        }else{
            DispatchQueue.main.async{
                self.showAlert(network.error.URLerror,customError: "Unable to open safari")
            }
        }
    }
    
    
}
