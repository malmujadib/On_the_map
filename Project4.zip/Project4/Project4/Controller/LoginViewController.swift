//
//  LoginViewController.swift
//  Project4
//
//  Created by Mohammed Mujadib on 28/10/1441 AH.
//  Copyright © 1441 mohammed al mujadib. All rights reserved.
//

import Foundation
import UIKit

class LoginViewController: UIViewController {
    @IBOutlet weak var Password: UITextField!
    @IBOutlet weak var Email: UITextField!
    @IBOutlet weak var LoginButton: UIButton!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        Email.delegate=self
        Email.clearButtonMode = .whileEditing
        
        Password.delegate=self
        Password.clearButtonMode = .whileEditing
       
    }

    override func viewWillDisappear(_ animated: Bool) {
          
          super.viewWillDisappear(animated)
          unsubscribeFromKeyboardNotifications()
      }
      
      override func viewWillAppear(_ animated: Bool) {
          super.viewWillAppear(animated)
          subscribeToKeyboardNotifications()
      }
     
     

      @objc func keyboardWillShow(_ notification:Notification) {
        if Password.isEditing && UIDevice.current.orientation.isLandscape{
            self.view.frame.origin.y = -getKeyboardHeight(notification)
          }
      }
      
      func getKeyboardHeight(_ notification:Notification) -> CGFloat {
          
          let userInfo = notification.userInfo
          let keyboardSize = userInfo![UIResponder.keyboardFrameEndUserInfoKey] as! NSValue // of CGRect
          return keyboardSize.cgRectValue.height
      }
      func subscribeToKeyboardNotifications(){
          NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(_:)), name: UIResponder.keyboardWillShowNotification, object: nil)
          NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(_:)), name: UIResponder.keyboardWillHideNotification, object: nil)
      }
      
      func unsubscribeFromKeyboardNotifications() {
          
          NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillShowNotification, object: nil)
          NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillHideNotification, object: nil)
          
      }
      @objc func keyboardWillHide(_ notification: Notification) {
       view.frame.origin.y = 0
          
      }
    
    @IBAction func Login(_ sender: Any) {
        network.login(username: Email.text!, password: Password.text!, completionHandler: {(response,error) in
            if response{
                self.performSegue(withIdentifier: "login", sender: nil)
            }else{
                self.errorAlert(error, stringError: "Unable to login")
            }
        })
        
        
    }
    
    @IBAction func singnup(_ sender: Any) {
        UIApplication.shared.open(URL(string:"https://auth.udacity.com/sign-up?next=https%3A%2F%2Fclassroom.udacity.com%2Fauthenticated")!, completionHandler: {(success) in
                   if success{
                       print("Able to open url")
                   }else{
                       print("unable to open url")
                   }
               })
        
        
    }
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            if segue.identifier=="login"{
                Email.text=""
                Password.text=""
            }
        }
        
        
    }

    extension LoginViewController:UITextFieldDelegate{
        func textFieldShouldReturn(_ textField: UITextField) -> Bool {
            textField.resignFirstResponder()
            
            return true
        }
}

