//
//  ErrorController.swift
//  Project4
//
//  Created by Mohammed Mujadib on 22/11/1441 AH.
//  Copyright © 1441 mohammed al mujadib. All rights reserved.
//

import UIKit

extension UIViewController{
    
    
    func errorAlert(_ error:Error?,stringError:String){
        let alert=UIAlertController(title: stringError, message: error?.localizedDescription ?? "", preferredStyle: .alert)
        let action=UIAlertAction(title: "OK", style: .default, handler: nil)
        alert.addAction(action)
        present(alert, animated: true, completion: nil)
    }
    
    func successAlert(stringSuccess:String){
        let alert=UIAlertController(title: "Success", message: stringSuccess, preferredStyle: .alert)
        let action=UIAlertAction(title: "OK", style: .default, handler: {(action) in
            DispatchQueue.main.async{
                self.dismiss(animated: true, completion: nil)
            }
        })
        alert.addAction(action)
        present(alert, animated: true, completion: nil)
    }
}

