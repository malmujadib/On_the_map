//
//  AddPin.swift
//  Project4
//
//  Created by Mohammed Mujadib on 22/11/1441 AH.
//  Copyright © 1441 mohammed al mujadib. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation
class AddPin: UIViewController{
    
    @IBOutlet weak var locationTextField: UITextField!
    @IBOutlet weak var urlTextField: UITextField!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    @IBOutlet weak var findLocationButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        locationTextField.delegate = self
        locationTextField.clearButtonMode = .whileEditing
        urlTextField.delegate = self
        urlTextField.clearButtonMode = .whileEditing
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        NotificationCenter.default.addObserver(self, selector: #selector(showKeyboard),name:UIResponder.keyboardDidShowNotification ,object:nil)
        NotificationCenter.default.addObserver(self, selector: #selector(hideKeyboard), name:UIResponder.keyboardDidHideNotification,object:nil)
    }
    
    @objc func showKeyboard(_ notification:Notification){
        
        let info=notification.userInfo
        let keyboardSize=info?[UIResponder.keyboardFrameEndUserInfoKey] as! NSValue
        if urlTextField.isEditing && UIDevice.current.orientation.isLandscape{
            self.view.frame.origin.y = -(keyboardSize.cgRectValue.height)
        }
    }
    
    @objc func hideKeyboard(_ notification:Notification){
        if self.view.frame.origin.y != 0{
            self.view.frame.origin.y=0
        }
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardDidShowNotification, object: nil)
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardDidHideNotification, object: nil)
    }
    
    @IBAction func findLocation(_ sender: UIButton) {
        print("button tapped")
        //Make sure all fields are entered before finding the location
        if locationTextField.text!.isEmpty || urlTextField.text!.isEmpty{
            errorAlert(nil, stringError: "Please fill out both text fields")
            return
        }
        getLocation(location: locationTextField.text!)
    }
    func getLocation(location searchTerm:String){
        
        showActivity(inProgress: true)
        
        let geoCoder=CLGeocoder()
        geoCoder.geocodeAddressString(searchTerm, completionHandler: {(placemarks,error) in
            guard let placemark=placemarks?.first else{
                DispatchQueue.main.async{
                    
                    self.showActivity(inProgress: false)
                    self.errorAlert(error,stringError:"Unable to find location")
                }
                return
            }
            DispatchQueue.main.async{
                self.showActivity(inProgress: false)
                self.performSegue(withIdentifier: "showPin", sender: placemark)
            }
        })
    }
    
    @IBAction func cancelPinAddition(_ sender: UIBarButtonItem) {
        dismiss(animated: true, completion: nil)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier=="showPin"{
            guard let placemark=sender as? CLPlacemark else{
                print("unable to retrive placemark")
                return
            }
            
            let showPin=segue.destination as! ShowPin
            showPin.placeMark=placemark
            showPin.mediaURL=urlTextField.text!
        }
    }
    
    func showActivity(inProgress:Bool){
        if inProgress{
            activityIndicator.startAnimating()
        }else{
            activityIndicator.stopAnimating()
        }
        findLocationButton.isEnabled = !inProgress
    }
}
extension AddPin:UITextFieldDelegate{
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
}

