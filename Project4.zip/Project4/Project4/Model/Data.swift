//
//  Data.swift
//  Project4
//
//  Created by Mohammed Mujadib on 28/10/1441 AH.
//  Copyright © 1441 mohammed al mujadib. All rights reserved.
//

import Foundation
class StudentData{
    static var list=[student]()
}
class LocationData{
    static var LocationID: String?
}
