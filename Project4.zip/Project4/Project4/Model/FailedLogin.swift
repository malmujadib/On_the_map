//
//  FailedLogin.swift
//  Project4
//
//  Created by Mohammed Mujadib on 28/10/1441 AH.
//  Copyright © 1441 mohammed al mujadib. All rights reserved.
//

import Foundation
struct Failed :Codable, LocalizedError {
    let status: Int
    let Error: String

var ErrorDescription: String?{
    return Error
}
}
