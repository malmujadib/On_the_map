//
//  StudentRequest.swift
//  Project4
//
//  Created by Mohammed Mujadib on 28/10/1441 AH.
//  Copyright © 1441 mohammed al mujadib. All rights reserved.
//

import Foundation
struct StudentRequest: Codable {
      let firstName: String
      let lastName: String
      let latitude: Double
      let longitude: Double
      let mapString: String
      let mediaURL: String
      let uniqueKey: String
}
