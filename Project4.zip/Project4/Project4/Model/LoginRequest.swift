//
//  LoginRequest.swift
//  Project4
//
//  Created by Mohammed Mujadib on 28/10/1441 AH.
//  Copyright © 1441 mohammed al mujadib. All rights reserved.
//

import Foundation
struct LoginRequest: Codable {
    let udacity: userinfo
}
struct userinfo: Codable {
    let userName: String
    let passwerd: String
    init(_ userName: String,_ passwerd: String){
    self.userName=userName
     self.passwerd=passwerd
    }
}
