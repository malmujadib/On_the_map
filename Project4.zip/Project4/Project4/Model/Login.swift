//
//  Login.swift
//  Project4
//
//  Created by Mohammed Mujadib on 28/10/1441 AH.
//  Copyright © 1441 mohammed al mujadib. All rights reserved.
//

import Foundation
struct account: Codable{
    let registered: Bool
      let key: String
}
struct session: Codable {
        let id: String
        let expiration: String
}
struct Login: Codable {
        let Account: account
        let Session: session
}
