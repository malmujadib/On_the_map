//
//  network.swift
//  Project4
//
//  Created by Mohammed Mujadib on 22/11/1441 AH.
//  Copyright © 1441 mohammed al mujadib. All rights reserved.
//

import Foundation
class network {
struct authorization {
    static var account = ""
    static var session = ""
}
enum error:Error,LocalizedError{
    case URLerror
    public var errorDescription: String?{
        switch self{
        case .URLerror:
            return NSLocalizedString("Invalid URL.", comment: "Invalid URL")
            
        }
        
    }
}
enum EndPoint {
    static let baseAPI = "https://onthemap-api.udacity.com/v1/"
    case student(String)
    case studentLocations
    case newStudent
    case updateStudent(String)
    case login
    case logout
    
    var stringValue:String{
        switch self{
        case .student(let accountKey):
            return EndPoint.baseAPI+"users/\(accountKey)"
        case .studentLocations:
            return EndPoint.baseAPI+"StudentLocation?order=-updatedAt&limit=100"
        case .newStudent:
            return EndPoint.baseAPI+"StudentLocation"
        case .updateStudent(let objectId):
            return EndPoint.baseAPI+"StudentLocation/\(objectId)"
        case .login:
            return EndPoint.baseAPI+"session"
        case .logout:
            return EndPoint.baseAPI+"session"
            
            
        }
        
    }
    var url:URL?{
        return URL(string: stringValue)
    }
    
}
class func Student (completionHandler:@escaping ([student],Error?)->()) {
    guard let url=EndPoint.studentLocations.url else{
        completionHandler([],error.URLerror)
        return
    }
    let session=URLSession.shared.dataTask(with: url, completionHandler: {(data,response,error) in
        
        guard let data=data else{
            
            DispatchQueue.main.async {
                completionHandler([],error)
                
            }
            return
        }
        
        
        let decoder=JSONDecoder()
        do{
            let responseObject=try decoder.decode(StudentResult.self,from:data)
            print(responseObject.result)
            DispatchQueue.main.async {
                completionHandler(responseObject.result,nil)
            }
            
        }
        catch{
            do{
                
                let studentError=try decoder.decode(Failed.self,from:data)
                DispatchQueue.main.async {
                    completionHandler([],studentError)
                }
            }
            catch{
                DispatchQueue.main.async {
                    completionHandler([],error)
                }
            }
        }
    })
    session.resume()
}
    class func StudentID (completionHandler:@escaping (StudentByID?,Error?)->()) {
           
         guard let url=EndPoint.student(authorization.account).url else{
               completionHandler(nil,error.URLerror)
               return
               
           }
           let session=URLSession.shared.dataTask(with: url, completionHandler: {(data,response,error) in
               
               guard let data=data else{
                   DispatchQueue.main.async {
                       completionHandler(nil,error)
                       
                   }
                   return
               }
               
               _ = data.subdata(in: 5..<data.count)
               
               let decoder=JSONDecoder()
               do{
                   let responseObject=try decoder.decode(StudentByID.self,from:data)
                   print(responseObject)
                   DispatchQueue.main.async {
                       completionHandler(responseObject,nil)
                   }
                   
               }
                   catch{
                   DispatchQueue.main.async {
                       completionHandler(nil,error)

                   }
               }
           })
           session.resume()
       }

class func login(username:String, password:String, completionHandler:@escaping(Bool,Error?)->()){
    guard let url=EndPoint.login.url else{
        
        completionHandler(false,error.URLerror)
        return
        
    }
    var request = URLRequest(url: url)
    request.addValue("application/json", forHTTPHeaderField: "Content-Type")
    request.addValue("application/json",forHTTPHeaderField: "Accept")
    request.httpMethod="POST"
    let userInfo = userinfo(username,password)
    let LoginBody=LoginRequest(udacity: userInfo)
    request.httpBody=try! JSONEncoder().encode(LoginBody)
    let session=URLSession.shared.dataTask(with: request, completionHandler: {(data,response,error) in
    
        guard let data=data else{
            
            DispatchQueue.main.async {
                completionHandler(false,error)
                
            }
            return
        }
        let newData = data.subdata(in: 5..<data.count)
        
        let decoder=JSONDecoder()
        do {
            
         
            let responseObject=try decoder.decode(Login.self, from: newData)
            authorization.account=responseObject.Account.key
            print(authorization.account)
            authorization.session=responseObject.Session.id
            print(authorization.session)
            DispatchQueue.main.async {
                completionHandler(true,nil)
                
            }
            
        }
        catch{
            do{
                let loginError=try decoder.decode(Failed.self,from:newData)
                DispatchQueue.main.async {
                    completionHandler(false,loginError)
                }
            }catch{
                DispatchQueue.main.async {
                    completionHandler(false,error)
                }
            }
        }
    })
    
    session.resume()
     
}
    
  
    
    class func Postloca(_ StudentByID:StudentByID,_ mediaURL:String,locationName:String,longitude:Double,latitude:Double,completionHandler:@escaping(NewStudent?,Error?)->()){
           guard let url=EndPoint.newStudent.url else{
               completionHandler(nil,error.URLerror)
               return
               
           }
           var request=URLRequest(url: url)
           request.httpMethod="POST"
           
           request.addValue("application/json", forHTTPHeaderField: "Content-Type")
           let newStudent=student(firstName: StudentByID.firstName, lastName: StudentByID.lastName, uniqueKey: StudentByID.key, mediaURL: mediaURL, longitude: longitude, latitude: latitude, mapString: locationName, objectId: "")
           request.httpBody=try! JSONEncoder().encode(newStudent)
           let session=URLSession.shared.dataTask(with: request, completionHandler: {(data,response,error) in
               
               guard let data=data else{
                   DispatchQueue.main.async {
                       completionHandler(nil,error)
                   }
                   return
               }
               
               
               let decoder=JSONDecoder()
               
               
               do{
                   let responseObject = try decoder.decode(NewStudent.self, from:data)
                   print(responseObject)
                   DispatchQueue.main.async {
                       completionHandler(responseObject,nil)
                   }
               }catch let decodeError{
                   print(decodeError)
                   DispatchQueue.main.async{
                       completionHandler(nil,decodeError)
                   }
               }
               
           })
           
           
           session.resume()
       }
       

class func putloca(_ StudentByID:StudentByID,_ mediaURL:String,locationName:String,longitude:Double,latitude:Double,objectId:String, completionHandler:@escaping(UpdateStudent?,Error?)->()){
       guard let url=EndPoint.updateStudent(objectId).url else{
           completionHandler(nil,error.URLerror)
           return
       }
       var request=URLRequest(url: url)
       request.httpMethod="POST"
       request.addValue("application/json", forHTTPHeaderField: "Content-Type")
       let updateStudent=student(firstName: StudentByID.firstName, lastName: StudentByID.lastName, uniqueKey: StudentByID.key, mediaURL: mediaURL, longitude: longitude, latitude: latitude, mapString: locationName, objectId: "")
       request.httpBody=try! JSONEncoder().encode(updateStudent)
       let session=URLSession.shared.dataTask(with: request, completionHandler: {(data,response,error) in
           
           guard let data=data else{
               DispatchQueue.main.async {
                   completionHandler(nil,error)
               }
               return
           }
           
           
           let decoder=JSONDecoder()
           
           
           do{
               let responseObject=try decoder.decode(UpdateStudent.self,from:data)
               print(responseObject)
               DispatchQueue.main.async {
                   completionHandler(responseObject,nil)
               }
           }catch let decodeError{
               print(decodeError)
               DispatchQueue.main.async{
                   completionHandler(nil,decodeError)
               }
           }
           
       })
       
       
       session.resume()
   }
class func Logout(completionHandler:@escaping (Bool,Error?)->()){
        
        guard let url=EndPoint.logout.url else{
            completionHandler(false,error.URLerror)
            return
        }
        
        
        var request=URLRequest(url: url)
        
        
        request.httpMethod="DELETE"
        
        let session=URLSession.shared.dataTask(with: request, completionHandler: {(data,response,error) in
            
            
            if let _ = data{
                authorization.account=""
                authorization.session=""
                DispatchQueue.main.async{
                    completionHandler(true,nil)
                }
            } else{
                DispatchQueue.main.async {
                    completionHandler(false,error)
                }
                return
            }
        })
        
        //run the session
        session.resume()
    }
}

