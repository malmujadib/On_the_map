//
//  UpdateStudent.swift
//  Project4
//
//  Created by Mohammed Mujadib on 28/10/1441 AH.
//  Copyright © 1441 mohammed al mujadib. All rights reserved.
//

import Foundation
struct UpdateStudent: Codable {
    let updatedAt : String
    
}
