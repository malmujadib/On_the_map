//
//  StudentByID.swift
//  Project4
//
//  Created by Mohammed Mujadib on 23/11/1441 AH.
//  Copyright © 1441 mohammed al mujadib. All rights reserved.
//

import Foundation
struct StudentByID: Codable {
    let lastName: String
    let firstName: String
    let key: String
    enum codingkey: String,CodingKey{
        case firstName = "first_name"
        case lastName = "last_name"
        case key
    }
}
